#!/usr/bin/env python3
"""Fetch and verify OpenWrt images for a supported device profile.

Two jobs, and the second one is the important one.

Fetching is unremarkable: the GitHub releases API, assets picked by name, a
`sha256sums.txt` that the release notes promise covers every asset, checked
before anything is handed to a flasher.

Gating is not.  The NAND on this board is **second-sourced** -- some units
carry an ESMT F50D1G41LB, others a Winbond W25N01KW -- and the two are not
interchangeable to the kernel.  A build without the Winbond ID entry does not
merely run slower on a Winbond unit: `spi-nand` fails to probe at all, no MTD
device is registered, `/proc/mtd` is empty, UBI cannot attach, and ath11k
cannot read caldata out of `0:ART`, so the radios never come up either.  On a
Wi-Fi-only install that is a device you cannot talk to any more.

The entry landed in commit 4d074a2, one day *after* the v1.6 tag. Releases at
or before that boundary can leave a Winbond unit without flash or radios;
this module exists to refuse such a mismatch regardless of which release is
current.

The release itself should say which parts it supports rather than having that
encoded here; if an asset named `nand-support.txt` is present it wins, and
the version table below is only the fallback for releases predating it.
"""

import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import urllib.error
import urllib.request

import devices


class ReleaseError(Exception):
    pass


def _api(path):
    """GET an API path.  Anonymous requests get 60/hour and shared NAT eats
    that fast, so fall back to an authenticated `gh` when one is configured
    before giving up."""
    url = f"https://api.github.com/{path}"
    req = urllib.request.Request(url)
    req.add_header("Accept", "application/vnd.github+json")
    req.add_header("User-Agent", "xiaomi-openwrt-install")
    token = os.environ.get("GITHUB_TOKEN")
    if token:
        req.add_header("Authorization", f"Bearer {token}")
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        if e.code in (403, 429):
            got = _api_via_gh(path)
            if got is not None:
                return got
            raise ReleaseError(
                "GitHub rate-limited this host (60 requests/hour anonymous). "
                "Set GITHUB_TOKEN, run `gh auth login`, or point the installer "
                "at an image directory you already downloaded."
            )
        raise ReleaseError(f"{url}: HTTP {e.code}")
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        got = _api_via_gh(path)
        if got is not None:
            return got
        raise ReleaseError(f"{url}: {type(e).__name__}: {e}")


def _api_via_gh(path):
    if not shutil.which("gh"):
        return None
    try:
        r = subprocess.run(["gh", "api", path], capture_output=True,
                           text=True, timeout=30)
        if r.returncode != 0:
            return None
        print("[*] (used an authenticated `gh api` -- anonymous quota exhausted)",
              file=sys.stderr)
        return json.loads(r.stdout)
    except Exception:                                            # noqa: BLE001
        return None


# v2 and later releases of the RD03v2 port: v2.0.0, v2.0.0-rc1, v2.1...
V2_TAG = re.compile(r"^v2(?:[.-]|$)")


def parse_version(tag):
    m = re.match(r"v?(\d+)\.(\d+)", str(tag))
    return (int(m.group(1)), int(m.group(2))) if m else None


class Release:
    def __init__(self, meta, profile=devices.RD03V2):
        self.profile = profile
        self.tag = meta.get("tag_name", "?")
        self.published = meta.get("published_at", "?")
        self.body = meta.get("body") or ""
        self.prerelease = bool(meta.get("prerelease"))
        self.assets = {
            a["name"]: {"url": a["browser_download_url"], "size": a["size"],
                        "digest": a.get("digest")}
            for a in meta.get("assets", [])
        }
        self.version = parse_version(self.tag)

    @property
    def is_v2(self):
        return isinstance(self.tag, str) and bool(V2_TAG.match(self.tag))

    def name_for(self, kind, flavour="default", wifi=False):
        """`initramfs_itb` + nss + wifi -> ...-initramfs-uImage-nss-wifi.itb

        v1.7 added a second initramfs per flavour whose `rc.local` brings the
        radios up while it is running from RAM, so an install needs no LAN
        cable.  The flavour suffix goes before the variant suffix, and only
        the initramfs artifacts have a -wifi twin -- there is still exactly
        one sysupgrade image per flavour, built from the radio-silent pass.
        """
        if kind not in self.profile.image_kinds:
            raise ReleaseError(f"unknown image kind {kind!r}")
        base = self.profile.image_kinds[kind]
        stem, _, ext = base.rpartition(".")
        if flavour not in ("default", "nss"):
            raise ReleaseError(f"unknown flavour {flavour!r}")
        # A v2 release ships one image set for both selections: the NSS data
        # plane is always on, and Wi-Fi offload is a runtime setting. Only a
        # v1.x release has a separate -nss build.
        if flavour == "nss" and not self.is_v2:
            stem += "-nss"
        if wifi:
            if not kind.startswith("initramfs"):
                raise ReleaseError(f"{kind} has no -wifi variant")
            stem += "-wifi"
        return f"{self.profile.release_prefix}-{stem}.{ext}"

    def require(self, kind, flavour="default", wifi=False):
        name = self.name_for(kind, flavour, wifi)
        if name not in self.assets:
            raise ReleaseError(
                f"{self.tag} has no asset {name!r}. Assets present: "
                + ", ".join(sorted(self.assets)) or "(none)"
            )
        return name

    def __repr__(self):
        return f"<Release {self.tag} ({len(self.assets)} assets)>"


def latest(profile=devices.RD03V2):
    meta = _api(f"repos/{profile.release_repo}/releases/latest")
    if meta.get("draft") or meta.get("prerelease"):
        raise ReleaseError("GitHub did not return a published stable release")
    return Release(meta, profile)


def by_tag(tag, profile=devices.RD03V2):
    return Release(_api(f"repos/{profile.release_repo}/releases/tags/{tag}"), profile)


def resolve(tag=None, profile=devices.RD03V2, destdir="images", *, offline=False,
            log=print):
    """Resolve a release once; only concrete tags may use a verified cache."""
    tag = tag or profile.default_release
    if offline:
        return from_cache(tag, profile, destdir)
    try:
        return latest(profile) if tag == "latest" else by_tag(tag, profile)
    except ReleaseError as online_error:
        if tag == "latest":
            raise ReleaseError(
                f"{online_error}\nTo use cached images, select an explicit release "
                "tag with --release TAG or --tag TAG and --offline.") from online_error
        try:
            rel = from_cache(tag, profile, destdir)
        except ReleaseError:
            raise online_error
        log(f"[!] release API unavailable; using verified {tag} cache")
        return rel


def from_cache(tag, profile=devices.RD03V2, destdir="images"):
    """Build release metadata from a previously verified tag-scoped cache."""
    if not tag or tag == "latest":
        raise ReleaseError(
            "offline operation requires an explicit release tag; "
            "use --release TAG or --tag TAG instead of 'latest'")
    stub = Release({"tag_name": tag, "assets": []}, profile)
    root = cache_dir(stub, destdir)
    sums_path = os.path.join(root, "sha256sums.txt")
    if not os.path.isfile(sums_path):
        raise ReleaseError(f"offline cache has no {sums_path}")

    sums = {}
    with open(sums_path) as source:
        for line in source:
            parts = line.split()
            if len(parts) == 2 and len(parts[0]) == 64:
                sums[parts[1].lstrip("*")] = parts[0].lower()

    assets = []
    for name, expected in sums.items():
        path = os.path.join(root, name)
        if not os.path.isfile(path):
            continue
        actual = sha256(path)
        if actual != expected:
            raise ReleaseError(
                f"offline cache corruption for {name}: {actual} != {expected}")
        assets.append({"name": name, "browser_download_url": "",
                       "size": os.path.getsize(path),
                       "digest": f"sha256:{actual}"})

    manifest_digest = sha256(sums_path)
    assets.append({"name": "sha256sums.txt", "browser_download_url": "",
                   "size": os.path.getsize(sums_path),
                   "digest": f"sha256:{manifest_digest}"})
    return Release({"tag_name": tag, "published_at": "offline cache",
                    "assets": assets}, profile)


# ---- download + verify ------------------------------------------------------


def cache_dir(rel, destdir):
    """Keep identically named assets from different release tags separate."""
    safe_tag = re.sub(r"[^A-Za-z0-9._-]+", "_", rel.tag).strip("._")
    if not safe_tag:
        raise ReleaseError(f"unsafe or empty release tag {rel.tag!r}")
    return os.path.join(destdir, safe_tag)


def api_digest(rel, name):
    value = (rel.assets.get(name, {}).get("digest") or "").strip().lower()
    return value.removeprefix("sha256:") or None


def expected_digest(rel, name, manifest_digest=None):
    """Reconcile GitHub's immutable asset digest with sha256sums.txt."""
    manifest_digest = (manifest_digest or "").strip().lower() or None
    github_digest = api_digest(rel, name)
    if manifest_digest and github_digest and manifest_digest != github_digest:
        raise ReleaseError(
            f"{rel.tag} is internally inconsistent for {name}:\n"
            f"  sha256sums.txt  {manifest_digest}\n"
            f"  GitHub asset   {github_digest}\n"
            "The release must be repaired before it is safe to install.")
    return manifest_digest or github_digest


def download(rel, name, destdir, progress=True):
    """Fetch one asset, resuming nothing and trusting nothing -- the caller
    verifies against sha256sums.txt afterwards."""
    if name not in rel.assets:
        raise ReleaseError(f"{rel.tag}: no asset named {name!r}")
    os.makedirs(destdir, exist_ok=True)
    path = os.path.join(destdir, name)
    want = rel.assets[name]["size"]
    github_digest = api_digest(rel, name)
    if os.path.exists(path) and os.path.getsize(path) == want:
        if not github_digest or sha256(path) == github_digest:
            return path
        print(f"[!] cached {name} failed GitHub's asset digest; downloading again")
    req = urllib.request.Request(rel.assets[name]["url"])
    req.add_header("User-Agent", "xiaomi-openwrt-install")
    tmp = path + ".part"
    got = 0
    with urllib.request.urlopen(req, timeout=60) as r, open(tmp, "wb") as fh:
        while True:
            chunk = r.read(262144)
            if not chunk:
                break
            fh.write(chunk)
            got += len(chunk)
            if progress and want:
                pct = 100 * got // want
                short = name.rsplit("-v2-", 1)[-1]
                print(f"\r    {short}: {pct:3d}%  {got >> 20}/{want >> 20} MiB",
                      end="", flush=True)
    if progress:
        print()
    if want and got != want:
        os.unlink(tmp)
        raise ReleaseError(f"{name}: got {got} B, release says {want}")
    if github_digest:
        got_digest = sha256(tmp)
        if got_digest != github_digest:
            os.unlink(tmp)
            raise ReleaseError(
                f"{name}: downloaded sha256 {got_digest}, GitHub records "
                f"{github_digest}")
    os.replace(tmp, path)
    return path


def checksums(rel, destdir):
    """Parse sha256sums.txt.  Absent on a release that predates it, in which
    case the caller gets nothing to check against and should say so out loud
    rather than pretend the download was verified."""
    if "sha256sums.txt" not in rel.assets:
        return {}
    path = download(rel, "sha256sums.txt", cache_dir(rel, destdir), progress=False)
    out = {}
    with open(path) as fh:
        for line in fh:
            parts = line.split()
            if len(parts) == 2 and len(parts[0]) == 64:
                out[parts[1].lstrip("*")] = parts[0]
    return out


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def get_images(rel, destdir, flavour="default", kinds=("initramfs_ubi", "sysupgrade"),
               wifi=False):
    """Download the images this install needs and verify every one of them.

    `wifi` selects the beaconing initramfs where one exists; the sysupgrade
    image has no such variant and is fetched unchanged either way.
    """
    sums = checksums(rel, destdir)
    out = {}
    cachedir = cache_dir(rel, destdir)
    for kind in kinds:
        name = rel.require(kind, flavour, wifi and kind.startswith("initramfs"))
        print(f"[*] {kind}: {name}")
        want = expected_digest(rel, name, sums.get(name))
        if not want:
            raise ReleaseError(
                f"{rel.tag} provides no trusted SHA-256 for {name}; refusing "
                "to use a length-only download")
        path = download(rel, name, cachedir)
        digest = sha256(path)
        if want and digest != want:
            raise ReleaseError(
                f"{name}: sha256 mismatch\n  got  {digest}\n  want {want}")
        if want:
            print(f"    sha256 ok ({digest[:16]}...)")
        out[kind] = {"name": name, "path": path, "sha256": digest,
                     "verified": bool(want)}
    return out


# ---- the NAND gate ----------------------------------------------------------


def nand_support(rel, destdir=None):
    """What this release says it can drive: {flash_type_code: part name}.

    v1.7 onward ships a `nand-support.txt` asset generated from the kernel
    that was actually built, so a release states this for itself instead of an
    installer guessing from version numbers.  Its format is one part per line,
    `#` starts a comment:

        11  c8:11  ESMT F50D1G41LB          # kernel: ESMT F50D1G41LB
        be  ef:be  Winbond W25N01KWZEIG     # kernel: Winbond W25N01KW

    The first column is the device byte the stock bootloader leaves in
    `flash_type`, which is how a unit self-identifies before anything is
    written.  Lines whose first column is `-` are parts the kernel knows but
    the bootloader cannot identify: such a chip cannot be this board's boot
    NAND, since the bootloader could not have read it to boot at all, so they
    are dropped rather than offered as a match.

    Returns None when the release says nothing, which the caller must treat as
    "fall back to the version table", never as "everything is supported".
    """
    if "nand-support.txt" not in rel.assets or destdir is None:
        return None
    path = download(rel, "nand-support.txt", cache_dir(rel, destdir), progress=False)
    parts = {}
    with open(path) as fh:
        for line in fh:
            line = line.split("#", 1)[0].strip()
            if not line:
                continue
            cols = line.split(None, 2)
            if len(cols) < 3 or cols[0] == "-":
                continue
            parts[cols[0].lower()] = cols[2].strip()
    return parts or None


def normalise_flash_type(value):
    """`0xBE`, `be`, `b` -> `be`.  The env holds it as bare lowercase hex."""
    return str(value).strip().lower().removeprefix("0x").zfill(2)


def check_nand(rel, part, destdir=None, flash_type=None):
    """(ok, reason) for flashing this unit's NAND with this release.

    `flash_type` is the authoritative key when the release declares its own
    support: it is what the bootloader measured, whereas `part` is a name this
    installer decoded.  Falls back to the name, then to the version table, and
    fails closed at every step.
    """
    if not part and not flash_type:
        return False, ("the NAND was not identified; nothing here can tell you "
                       "whether this release can drive it")

    declared = nand_support(rel, destdir)
    if declared is not None:
        if flash_type:
            code = normalise_flash_type(flash_type)
            if code in declared:
                return True, (f"{rel.tag} declares flash_type 0x{code} "
                              f"({declared[code]}) supported")
            return False, (
                f"{rel.tag} does not list flash_type 0x{code} among the "
                f"{len(declared)} parts it declares. Flashing it would leave a "
                "device whose kernel cannot probe its own flash.")
        for code, name in declared.items():
            if name.lower() in part.lower() or part.lower() in name.lower():
                return True, (f"{rel.tag} declares {name!r} supported "
                              f"(flash_type 0x{code})")
        return False, f"{rel.tag} does not declare support for {part!r}"

    need = rel.profile.nand_min_version.get(part)
    if need is None:
        what = part or f"flash_type 0x{normalise_flash_type(flash_type)}"
        return False, (f"{what} is not a part this installer knows about, and "
                       f"{rel.tag} ships no nand-support.txt to ask; no release "
                       "is known to drive it")
    if rel.version is None:
        return False, f"cannot read a version out of the tag {rel.tag!r}"
    if rel.version >= need:
        return True, (f"{part} needs >= v{need[0]}.{need[1]}, {rel.tag} is "
                      "new enough")
    return False, (
        f"{part} needs >= v{need[0]}.{need[1]} and {rel.tag} predates it. "
        "For the Winbond W25N01KW the spinand ID entry landed after v1.6 "
        "(commit 4d074a2); without it the kernel registers no MTD at all and "
        "the device comes up with no flash and no radios. Select a release "
        "that carries it or use a validated local build."
    )


def main(argv):
    import argparse
    ap = argparse.ArgumentParser(description="Inspect/fetch a supported OpenWrt release.")
    devices.add_device_argument(ap)
    ap.add_argument("--tag", default=None,
                    help="release tag or 'latest' (default: profile selection)")
    ap.add_argument("--flavour", default="default", choices=("default", "nss"))
    ap.add_argument("--dest", default="images")
    ap.add_argument("--download", action="store_true")
    ap.add_argument("--offline", action="store_true",
                    help="use verified cached images; requires an explicit --tag")
    ap.add_argument("--nand", default=None,
                    help="part name from the probe, e.g. 'Winbond W25N01KW'")
    ap.add_argument("--flash-type", default=None,
                    help="the unit's `nvram get flash_type`, e.g. 11 or be")
    ap.add_argument("--wifi", action="store_true",
                    help="select the beaconing initramfs (v1.7+)")
    args = ap.parse_args(argv[1:])
    profile = devices.get_profile(args.device)

    rel = resolve(args.tag, profile, args.dest, offline=args.offline)
    print(f"{rel.tag}  published {rel.published}  ({len(rel.assets)} assets)")
    for n in sorted(rel.assets):
        print(f"  {rel.assets[n]['size']:>12} B  {n}")
    print()
    for kind in profile.image_kinds:
        try:
            print(f"  {kind:<14} -> "
                  f"{rel.require(kind, args.flavour, args.wifi and kind.startswith('initramfs'))}")
        except ReleaseError as e:
            print(f"  {kind:<14} -> MISSING ({e})")

    if args.nand or args.flash_type:
        # nand-support.txt has to be fetched to be consulted, so always give
        # check_nand somewhere to put it -- otherwise the gate silently falls
        # back to the version table and reports on the wrong evidence.
        ok, why = check_nand(rel, args.nand, args.dest, args.flash_type)
        print(f"\nNAND gate: {'PASS' if ok else 'REFUSE'} -- {why}")
        if not ok and not args.download:
            return 1
    if args.download:
        print()
        get_images(rel, args.dest, args.flavour, wifi=args.wifi)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main(sys.argv))
    except ReleaseError as exc:
        print(f"[-] {exc}", file=sys.stderr)
        sys.exit(1)
